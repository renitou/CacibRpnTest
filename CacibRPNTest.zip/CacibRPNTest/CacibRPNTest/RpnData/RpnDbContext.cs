﻿using CacibRPNTest.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace CacibRPNTest.RpnData
{
    public class RpnDbContext : DbContext, IRpnDbContext
    {
        public DbSet<Stack> Stacks { get; set; }
        public DbSet<StackElement> StackElements { get; set; }

        public RpnDbContext ()
	    {

	    }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}